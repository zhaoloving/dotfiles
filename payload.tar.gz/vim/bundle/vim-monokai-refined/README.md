vim-monokai-refined
===================

A Vim color scheme ported from the [Monokai Refined variant for TextMate/Sublime Text 2](https://github.com/cafarm/soda-refined-theme/tree/master/Color%20Schemes), plugged through sickill's [coloration](https://github.com/sickill/coloration) converter, with minor adjustments like bold keywords and &c.
